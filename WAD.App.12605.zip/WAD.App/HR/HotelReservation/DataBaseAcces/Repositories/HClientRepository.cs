﻿
using System.Collections.Generic;
using System.Linq;
using HotelReservationAPI.DAL;
using HotelReservationAPI.Models;

namespace HotelReservationAPI.Repositories
{
    public class HClientRepository : IhClientRepository
    {
        // initializing dbcontext public to private
        private readonly HotelDbContext __dbContext;
        public HClientRepository(HotelDbContext dbContext)
        {
            __dbContext = dbContext;
        }

        // Save function implemented later
        public void Save()
        {
            __dbContext.SaveChanges();
        }

        public void CreateNewClient(hClient client)
        {
            __dbContext.Add(client);
            Save();

        }

        public void DeleteClientByID(int ClientID)
        {
            var foundClient = __dbContext.HClients.Find(ClientID);
            __dbContext.HClients.Remove(foundClient);
            Save();
        }

        public IEnumerable<hClient> RetrieveAll()
        {
            return __dbContext.HClients.ToList();
        }

        public hClient RetrieveByID(int ClientID)
        {

            return __dbContext.HClients.Find(ClientID);
        }

        public void UpdateClient(hClient client)
        {
            __dbContext.Entry(client).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            Save();
        }


    }
}
