﻿using System.Collections.Generic;
using HotelReservationAPI.Models;

namespace HotelReservationAPI.Repositories
{
    public interface IhClientRepository
    {

        void CreateNewClient(hClient client);


        IEnumerable<hClient> RetrieveAll();


        hClient RetrieveByID(int ClientID);

        void DeleteClientByID(int ClientID);

        void UpdateClient(hClient client);

    }
}
