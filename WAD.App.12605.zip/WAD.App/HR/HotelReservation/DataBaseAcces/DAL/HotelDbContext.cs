﻿using HotelReservationAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace HotelReservationAPI.DAL
{
    public class HotelDbContext : DbContext
    {
        public HotelDbContext(DbContextOptions<HotelDbContext> options) : base(options)
        {
            Database.EnsureCreated();
        }
        public DbSet<hClient> HClients { get; set; }
    }
}
