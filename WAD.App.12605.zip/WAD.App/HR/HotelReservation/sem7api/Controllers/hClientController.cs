﻿
using System.Transactions;
using HotelReservationAPI.Models;
using HotelReservationAPI.Repositories;

using Microsoft.AspNetCore.Mvc;



namespace HotelReservationAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class hClientController : ControllerBase
    {
        private readonly IhClientRepository __clientRepository;

        public hClientController(IhClientRepository clientRepository)
        {
            __clientRepository = clientRepository;
        }

        
        [HttpGet]
        public IActionResult Get()
        {
            return new OkObjectResult(__clientRepository.RetrieveAll());
        }

        
        [HttpGet("{id}", Name = "GetClientByID")]
        public IActionResult GetClientById(int ID)
        {
            return new OkObjectResult(__clientRepository.RetrieveByID(ID));
        }

        
        [HttpPut("{id}")]
        public IActionResult UpdateClient([FromBody] hClient client)
        {
            if (client != null)
            {
                using (var scope = new TransactionScope())
                {
                    __clientRepository.UpdateClient(client);
                    scope.Complete();
                    return new OkResult();
                }
            }
            return new NoContentResult();
        }

       

        [HttpPost]
        public IActionResult CreateNewClient(hClient client
            )
        {
            using (var scope = new TransactionScope())
            {
                __clientRepository.UpdateClient(client);
                scope.Complete();
                return CreatedAtAction(nameof(Get), new { ID = client.Id }, client);
            }

        }

        
        [HttpDelete("{id}")]
        public IActionResult DeleteClient(int ID)
        {

            __clientRepository.DeleteClientByID(ID);
            return new OkResult();
        }
    }
}
